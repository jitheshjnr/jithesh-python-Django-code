# -*- coding: utf-8 -*-
from Book import Book
from Catalog import Catalog
from User import Member, Librarian

b1 = Book('James Bond','JNR', '1997',1199)
b1.addBookItem('007HR','BS143')
b1.addBookItem('007HR','BS143')

b1.printBook()

catalog = Catalog()

b = catalog.addBook('Pirate of Carabian','Sagar', '1988',620)
catalog.addBookItem(b, '143HR','BS144')
catalog.addBookItem(b, '142HR','BS145')
catalog.addBookItem(b, '133HR','BS146')

b = catalog.addBook('Python','GJS', '2019',318)
catalog.addBookItem(b, '897HR','BS147')

catalog.displayAllBooks()

m1 = Member("Sagar","Santhepate",43,'kirthdj898','hjhdyhu44')

librarian = Librarian("Gagan","Bangalore",34,'jfkfjaii','S11E32X123') 
print (m1)
print (librarian)


b = catalog.searchByName('James Bond')
print (b)

b = catalog.searchByName('Pirate of Carabian')
print (b)

b = catalog.searchByAuthor('Python')
print (b)

#catalog.removeBookItem('Shoe Dog','124hg')
#catalog.displayAllBooks()
#m1.issueBook

b = catalog.RequestBook("")
print (b,"Book issued Successfully")

b = catalog.returnBook('')
print (b,"Book returned Successfully Thank you")
#m1.issueBook
